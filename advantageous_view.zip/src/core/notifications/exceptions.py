class NotificationNotFoundException(Exception):
    pass
