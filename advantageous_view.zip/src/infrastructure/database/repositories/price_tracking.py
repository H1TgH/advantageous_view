from uuid import UUID

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from core.price_tracking.entities import (
    CreateSubscriptionDTO,
    PriceHistoryItemDTO,
    PriceSubscriptionDTO,
    UpdateSubscriptionNotificationsDTO,
)
from infrastructure.database.models.price_tracking import PriceHistoryModel, PriceSubscriptionModel
from infrastructure.database.models.users import UserModel


class PriceTrackingRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add_subscription(self, user_id: UUID, dto: CreateSubscriptionDTO) -> PriceSubscriptionDTO:
        model = PriceSubscriptionModel(
            user_id=user_id,
            product_id=dto.product_id,
            title=dto.title,
            url=dto.url,
            marketplace=dto.marketplace,
            target_price=dto.target_price,
            is_active=True,
            notify_in_app=dto.notify_in_app,
            notify_email=dto.notify_email,
        )
        self.session.add(model)
        await self.session.flush()
        return self._sub_to_dto(model)

    async def add_price_history(self, subscription_id: UUID, price: float) -> PriceHistoryItemDTO:
        model = PriceHistoryModel(subscription_id=subscription_id, price=price)
        self.session.add(model)
        await self.session.flush()
        return self._hist_to_dto(model)

    async def get_subscriptions_by_user_id(self, user_id: UUID) -> list[PriceSubscriptionDTO]:
        stmt = (
            select(PriceSubscriptionModel)
            .where(PriceSubscriptionModel.user_id == user_id)
            .order_by(PriceSubscriptionModel.created_at.desc())
        )
        result = await self.session.execute(stmt)
        return [self._sub_to_dto(m) for m in result.scalars().all()]

    async def get_subscription_by_user_and_product(self, user_id: UUID, product_id: str) -> PriceSubscriptionDTO | None:
        stmt = select(PriceSubscriptionModel).where(
            PriceSubscriptionModel.user_id == user_id,
            PriceSubscriptionModel.product_id == product_id,
        )
        result = await self.session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._sub_to_dto(model) if model else None

    async def get_subscription_by_id_and_user(
        self,
        subscription_id: UUID,
        user_id: UUID,
    ) -> PriceSubscriptionDTO | None:
        stmt = select(PriceSubscriptionModel).where(
            PriceSubscriptionModel.id == subscription_id,
            PriceSubscriptionModel.user_id == user_id,
        )
        result = await self.session.execute(stmt)
        model = result.scalar_one_or_none()
        return self._sub_to_dto(model) if model else None

    async def update_notifications(
        self,
        subscription_id: UUID,
        user_id: UUID,
        dto: UpdateSubscriptionNotificationsDTO,
    ) -> PriceSubscriptionDTO | None:
        stmt = select(PriceSubscriptionModel).where(
            PriceSubscriptionModel.id == subscription_id,
            PriceSubscriptionModel.user_id == user_id,
        )
        result = await self.session.execute(stmt)
        model = result.scalar_one_or_none()
        if not model:
            return None

        model.notify_in_app = dto.notify_in_app
        model.notify_email = dto.notify_email
        await self.session.flush()
        return self._sub_to_dto(model)

    async def delete_subscription(self, subscription_id: UUID) -> None:
        stmt = delete(PriceSubscriptionModel).where(PriceSubscriptionModel.id == subscription_id)
        await self.session.execute(stmt)

    async def get_price_history(self, subscription_id: UUID) -> list[PriceHistoryItemDTO]:
        stmt = (
            select(PriceHistoryModel)
            .where(PriceHistoryModel.subscription_id == subscription_id)
            .order_by(PriceHistoryModel.created_at.desc())
        )
        result = await self.session.execute(stmt)
        return [self._hist_to_dto(m) for m in result.scalars().all()]

    async def get_last_price(self, subscription_id: UUID) -> float | None:
        stmt = (
            select(PriceHistoryModel.price)
            .where(PriceHistoryModel.subscription_id == subscription_id)
            .order_by(PriceHistoryModel.created_at.desc())
            .limit(1)
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_active_subscriptions_with_emails(self) -> list[tuple[PriceSubscriptionDTO, UUID, str]]:
        stmt = (
            select(PriceSubscriptionModel, UserModel.email)
            .join(UserModel, UserModel.id == PriceSubscriptionModel.user_id)
            .where(PriceSubscriptionModel.is_active.is_(True))
        )
        result = await self.session.execute(stmt)
        rows = result.all()
        return [(self._sub_to_dto(row[0]), row[0].user_id, row[1]) for row in rows]

    @staticmethod
    def _sub_to_dto(model: PriceSubscriptionModel) -> PriceSubscriptionDTO:
        return PriceSubscriptionDTO(
            id=model.id,
            product_id=model.product_id,
            title=model.title,
            url=model.url,
            marketplace=model.marketplace,
            target_price=model.target_price,
            is_active=model.is_active,
            notify_in_app=model.notify_in_app,
            notify_email=model.notify_email,
            created_at=model.created_at,
        )

    @staticmethod
    def _hist_to_dto(model: PriceHistoryModel) -> PriceHistoryItemDTO:
        return PriceHistoryItemDTO(
            id=model.id,
            subscription_id=model.subscription_id,
            price=model.price,
            created_at=model.created_at,
        )
